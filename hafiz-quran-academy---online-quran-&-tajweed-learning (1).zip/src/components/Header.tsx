import React, { useState, useEffect } from 'react';
import { BookOpen, Menu, X, MessageCircle, PhoneCall, Palette } from 'lucide-react';
import { WHATSAPP_NUMBER } from '../data/quranAcademyData';
import { useTheme } from '../context/ThemeContext';

interface HeaderProps {
  onOpenTrial: () => void;
  onOpenTheme?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenTrial, onOpenTheme }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { currentTheme } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'What We Teach', href: '#services' },
    { name: 'Courses', href: '#courses' },
    { name: 'Why Us', href: '#why-us' },
    { name: 'How It Works', href: '#how-it-works' },
    { name: 'Contact', href: '#contact' },
  ];

  const handleWhatsAppClick = () => {
    const message = encodeURIComponent("Assalamu Alaikum, I would like to inquire about Quran classes at Hafiz Quran Academy.");
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[var(--color-canvas)]/95 backdrop-blur-md shadow-sm border-b border-[var(--color-border-subtle)] py-3'
          : 'bg-[var(--color-canvas)] border-b border-[var(--color-border-subtle)]/60 py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Brand Wordmark */}
          <a
            href="#home"
            className="flex items-center gap-2.5 group hover:opacity-90 transition-opacity"
            aria-label="Hafiz Quran Academy - Home"
          >
            <div
              className="w-10 h-10 rounded-xl text-white flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform duration-200"
              style={{ backgroundColor: currentTheme.primary }}
            >
              {/* Refined Book & Crescent SVG */}
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
                <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
                <path d="M12 7v14" />
              </svg>
            </div>
            <div className="flex flex-col">
              <span
                className="font-serif text-xl sm:text-2xl font-bold tracking-tight leading-none"
                style={{ color: currentTheme.primary }}
              >
                Hafiz
              </span>
              <span
                className="text-[10px] sm:text-xs font-semibold uppercase tracking-wider mt-0.5"
                style={{ color: currentTheme.accent }}
              >
                Quran Academy
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-[var(--color-text-main)] hover:text-[var(--color-primary)] transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-[var(--color-primary)] hover:after:w-full after:transition-all after:duration-200"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Header Action CTAs */}
          <div className="hidden sm:flex items-center gap-2.5">
            {/* Color Palette Theme Button */}
            <button
              onClick={onOpenTheme}
              type="button"
              className="p-2.5 text-[var(--color-text-muted)] hover:text-[var(--color-primary)] hover:bg-[var(--color-primary-soft)] rounded-xl transition-colors border border-[var(--color-border-subtle)] flex items-center gap-1.5 text-xs font-medium cursor-pointer"
              title="Change Website Colors"
              aria-label="Change Website Colors"
            >
              <div
                className="w-3.5 h-3.5 rounded-full border border-black/15 shadow-2xs"
                style={{ backgroundColor: currentTheme.primary }}
              />
              <span className="text-[11px]">Theme</span>
            </button>

            <button
              onClick={handleWhatsAppClick}
              type="button"
              className="p-2.5 text-[var(--color-primary)] hover:bg-[var(--color-primary-soft)] rounded-xl transition-colors border border-[var(--color-border-subtle)] cursor-pointer"
              title="Message on WhatsApp"
              aria-label="Message on WhatsApp"
            >
              <MessageCircle className="w-4 h-4" />
            </button>
            <button
              onClick={onOpenTrial}
              type="button"
              className="inline-flex items-center justify-center px-4 sm:px-5 py-2.5 text-xs sm:text-sm font-semibold text-white rounded-xl transition-all shadow-sm hover:shadow active:scale-[0.98] whitespace-nowrap cursor-pointer hover:brightness-95"
              style={{ backgroundColor: currentTheme.primary }}
            >
              Start Free Trial
            </button>
          </div>

          {/* Mobile Menu Hamburger */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              onClick={onOpenTheme}
              type="button"
              className="p-2 text-[var(--color-text-muted)] hover:bg-[var(--color-primary-soft)] rounded-lg border border-[var(--color-border-subtle)]"
              aria-label="Change Color Theme"
            >
              <Palette className="w-4 h-4" style={{ color: currentTheme.primary }} />
            </button>
            <button
              onClick={onOpenTrial}
              type="button"
              className="px-3 py-1.5 text-xs font-semibold text-white rounded-lg"
              style={{ backgroundColor: currentTheme.primary }}
            >
              Trial
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              type="button"
              className="p-2 text-[var(--color-text-main)] hover:text-[var(--color-primary)] rounded-lg hover:bg-[var(--color-primary-soft)]"
              aria-label="Toggle navigation menu"
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[var(--color-canvas)] border-b border-[var(--color-border-subtle)] shadow-lg animate-fadeIn">
          <div className="max-w-7xl mx-auto px-4 pt-3 pb-6 space-y-2">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2 rounded-lg text-base font-medium text-[var(--color-text-main)] hover:bg-[var(--color-primary-soft)] hover:text-[var(--color-primary)] transition-colors"
              >
                {link.name}
              </a>
            ))}
            <div className="pt-4 border-t border-[var(--color-border-subtle)] flex flex-col gap-2.5">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenTrial();
                }}
                type="button"
                className="w-full text-center px-4 py-3 text-sm font-semibold text-white rounded-xl shadow-sm"
                style={{ backgroundColor: currentTheme.primary }}
              >
                Book a Free Trial Class
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  handleWhatsAppClick();
                }}
                type="button"
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium rounded-xl border border-[var(--color-border-subtle)]"
                style={{ color: currentTheme.primary, backgroundColor: currentTheme.primarySoft }}
              >
                <MessageCircle className="w-4 h-4" />
                Message on WhatsApp
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  if (onOpenTheme) onOpenTheme();
                }}
                type="button"
                className="w-full flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-[var(--color-text-muted)] bg-white rounded-xl border border-[var(--color-border-subtle)]"
              >
                <Palette className="w-3.5 h-3.5" style={{ color: currentTheme.primary }} />
                Change Academy Colors
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

